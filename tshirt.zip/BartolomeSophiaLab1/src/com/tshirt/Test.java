package com.tshirt;

public class Test {

	public static void main(String[] args) {
		Tshirt t1 = new Tshirt();
		t1.setBrand ("Adidas");
		t1.setLength(27);
		t1.setWidth(32.5);
		t1.setSize("Medium");
		t1.setColor("Pink");
		
	System.out.println("Brand: " + t1.getBrand());
	System.out.println("Length: " + t1.getLength());
	System.out.println("Width: " + t1.getWidth());
	System.out.println("Size: " + t1.getSize());
	System.out.println("Color: " + t1.getColor());
	
	System.out.println("");
	
	Tshirt t2 = new Tshirt();
	t2.setBrand ("Penshoppe");
	t2.setLength(30);
	t2.setWidth(33.5);
	t2.setSize("Large");
	t2.setColor("Blue");
	
	System.out.println("Brand: " + t2.getBrand());
	System.out.println("Length: " + t2.getLength());
	System.out.println("Width: " + t2.getWidth());
	System.out.println("Size: " + t2.getSize());
	System.out.println("Color: " + t2.getColor());

	System.out.println("");
	
	Tshirt t3 = new Tshirt();
	t3.setBrand ("Gucci");
	t3.setLength(25);
	t3.setWidth(32.5);
	t3.setSize("Small");
	t3.setColor("White");

	System.out.println("Brand: " + t3.getBrand());
	System.out.println("Length: " + t3.getLength());
	System.out.println("Width: " + t3.getWidth());
	System.out.println("Size: " + t3.getSize());
	System.out.println("Color: " + t3.getColor());
	}

	}

